/**
 * Startdaten für den Seitentest (sample.html).
 * - Watchlist-Eintrag im ALTEN Format (v1.0) → prüft die Migration
 * - Preisverlauf: Besuch vor 2 Tagen mit bestem Angebot 118,00 € inkl. Porto
 */
window.__MTGDS_SEED = {
  sync: {
    'wl:/Magic/Products/Singles/Mirrodin/Chrome-Mox': {
      name: 'Chrommox', url: 'https://www.cardmarket.com/de/Magic/Products/Singles/Mirrodin/Chrome-Mox',
      target: 120, added: 0
    }
  },
  local: {
    'hist:/Magic/Products/Singles/Mirrodin/Chrome-Mox': {
      nameKey: 'chromemox', title: 'Chrommox', expansion: 'Mirrodin', path: '/Magic/Products/Singles/Mirrodin/Chrome-Mox',
      entries: [{ t: Date.now() - 2 * 864e5, loadId: 1, price: 114.05, eff: 118.00, seller: 'Früher' }]
    }
  }
};
